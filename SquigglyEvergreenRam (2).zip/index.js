"use strict";

const express = require('express');
var bodyParser = require('body-parser');
const router = require('./router');

const app = express();

app.use(express.json());
app.use(bodyParser());
app.use("/", router);
app.set("json spaces", 4);
app.set('port', (process.env.PORT || 5000));
app.get('/', function(req, res) {
  res.send('<div style="margin-top: 15%;" class="server-message"><h1 style="font-size: 85px;margin: 0;font-weight: 300;    line-height: 1.1;color:grey;text-align: center;">ĐỊT MẸ MÀY</h1></div>')
}).listen(app.get('port'), () => {
  console.log('START!');
})
