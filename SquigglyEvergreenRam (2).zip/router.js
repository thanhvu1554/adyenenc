"use strict";

const router = require('express').Router()

const adyenEncrypt = require('./lib/adyenEncrypt')

// POST
router.post('/adyenEncrypt', adyenEncrypt)

module.exports = router